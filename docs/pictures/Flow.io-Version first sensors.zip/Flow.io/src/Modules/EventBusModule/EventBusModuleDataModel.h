#pragma once
/**
 * @file EventBusModuleDataModel.h
 * @brief EventBus runtime data model contribution.
 */

// Add your module runtime structs here.
// Example marker for generator:
// MODULE_DATA_MODEL: <TypeName> <memberName>
