#pragma once
/**
 * @file SystemMonitorRuntime.h
 * @brief SystemMonitor runtime helpers and keys.
 */

// Add runtime helpers, keys, and setters for this module here.
