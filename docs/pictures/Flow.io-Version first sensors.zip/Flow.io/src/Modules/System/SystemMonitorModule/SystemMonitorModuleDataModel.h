#pragma once
/**
 * @file SystemMonitorModuleDataModel.h
 * @brief SystemMonitor runtime data model contribution.
 */

// Add your module runtime structs here.
// Example marker for generator:
// MODULE_DATA_MODEL: <TypeName> <memberName>
