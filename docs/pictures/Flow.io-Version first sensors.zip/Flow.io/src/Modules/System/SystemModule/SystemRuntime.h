#pragma once
/**
 * @file SystemRuntime.h
 * @brief System runtime helpers and keys.
 */

// Add runtime helpers, keys, and setters for this module here.
