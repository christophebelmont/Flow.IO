#pragma once
/**
 * @file CommandModuleDataModel.h
 * @brief Command runtime data model contribution.
 */

// Add your module runtime structs here.
// Example marker for generator:
// MODULE_DATA_MODEL: <TypeName> <memberName>
