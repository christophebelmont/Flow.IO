#pragma once
/**
 * @file ConfigStoreModuleDataModel.h
 * @brief ConfigStore runtime data model contribution.
 */

// Add your module runtime structs here.
// Example marker for generator:
// MODULE_DATA_MODEL: <TypeName> <memberName>
