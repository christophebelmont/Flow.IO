#pragma once
/**
 * @file LogSerialSinkRuntime.h
 * @brief LogSerialSink runtime helpers and keys.
 */

// Add runtime helpers, keys, and setters for this module here.
