#pragma once
/**
 * @file LogHubRuntime.h
 * @brief LogHub runtime helpers and keys.
 */

// Add runtime helpers, keys, and setters for this module here.
