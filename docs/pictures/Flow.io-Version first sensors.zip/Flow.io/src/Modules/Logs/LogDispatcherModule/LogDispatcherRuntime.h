#pragma once
/**
 * @file LogDispatcherRuntime.h
 * @brief LogDispatcher runtime helpers and keys.
 */

// Add runtime helpers, keys, and setters for this module here.
