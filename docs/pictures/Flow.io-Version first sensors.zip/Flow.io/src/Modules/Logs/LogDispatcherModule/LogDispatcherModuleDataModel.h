#pragma once
/**
 * @file LogDispatcherModuleDataModel.h
 * @brief LogDispatcher runtime data model contribution.
 */

// Add your module runtime structs here.
// Example marker for generator:
// MODULE_DATA_MODEL: <TypeName> <memberName>
