#pragma once
#include <cstdint>

namespace app::controllers {

/** Abstract sampling controller interface (fixed-rate invocation). */
class ControllerBase {
public:
  virtual ~ControllerBase() = default;
  virtual void setEnabled(bool en) = 0;
  virtual void setSetpoint(double sp) = 0;
  virtual void onSample(double input, int64_t ts_us) = 0;
  virtual double lastOutput() const = 0;
};

} // namespace app::controllers
