#include "state/state_store.hpp"
#include <algorithm>

using namespace app::state;

bool StateStore::setBool(const char* key, bool v) {
  { std::lock_guard<std::mutex> lock(m_); b_[key] = v; }
  notify(key); return true;
}
bool StateStore::getBool(const char* key, bool& out) const {
  std::lock_guard<std::mutex> lock(m_);
  auto it = b_.find(key); if (it==b_.end()) return false; out = it->second; return true;
}
bool StateStore::setInt(const char* key, int64_t v)  { { std::lock_guard<std::mutex> lock(m_); i_[key]=v; } notify(key); return true; }
bool StateStore::getInt(const char* key, int64_t& o) const { std::lock_guard<std::mutex> lock(m_); auto it=i_.find(key); if(it==i_.end()) return false; o=it->second; return true; }
bool StateStore::setDouble(const char* k, double v){ { std::lock_guard<std::mutex> lock(m_); d_[k]=v; } notify(k); return true; }
bool StateStore::getDouble(const char* k, double& o) const { std::lock_guard<std::mutex> lock(m_); auto it=d_.find(k); if(it==d_.end()) return false; o=it->second; return true; }
bool StateStore::setString(const char* k, const std::string& v){ { std::lock_guard<std::mutex> lock(m_); s_[k]=v; } notify(k); return true; }
bool StateStore::getString(const char* k, std::string& o) const { std::lock_guard<std::mutex> lock(m_); auto it=s_.find(k); if(it==s_.end()) return false; o=it->second; return true; }
bool StateStore::setJson(const char* k, const std::string& v){ { std::lock_guard<std::mutex> lock(m_); j_[k]=v; } notify(k); return true; }
bool StateStore::getJson(const char* k, std::string& o) const { std::lock_guard<std::mutex> lock(m_); auto it=j_.find(k); if(it==j_.end()) return false; o=it->second; return true; }

int StateStore::watch(const char* key, Watcher cb) {
  std::lock_guard<std::mutex> lock(m_);
  int id = next_id_++;
  watchers_[id] = {key, std::move(cb)};
  watchers_by_key_[key].push_back(id);
  return id;
}

void StateStore::unwatch(int id) {
  std::lock_guard<std::mutex> lock(m_);
  auto it = watchers_.find(id);
  if (it == watchers_.end()) return;
  auto key = it->second.first;
  watchers_.erase(it);
  auto& vec = watchers_by_key_[key];
  vec.erase(std::remove(vec.begin(), vec.end(), id), vec.end());
}

void StateStore::notify(const char* key) {
  std::vector<Watcher> to_call;
  {
    std::lock_guard<std::mutex> lock(m_);
    auto it = watchers_by_key_.find(key);
    if (it != watchers_by_key_.end()) {
      to_call.reserve(it->second.size());
      for (int id : it->second) to_call.push_back(watchers_[id].second);
    }
  }
  for (auto& cb : to_call) cb(key);
}
