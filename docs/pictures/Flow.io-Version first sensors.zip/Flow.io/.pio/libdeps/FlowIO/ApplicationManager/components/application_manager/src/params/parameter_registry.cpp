#include "params/parameter_registry.hpp"

using namespace app::params;

bool Channel::push(double v, int64_t ts_us_app, int64_t ts_rt) {
  std::lock_guard<std::mutex> l(m_);
  data_[head_] = {ts_us_app, ts_rt, v};
  head_ = (head_ + 1) % cap_;
  any_ = true;
  return true;
}

bool Channel::readLatest(ParamSample& out) const {
  std::lock_guard<std::mutex> l(m_);
  if (!any_) return false;
  size_t idx = (head_ + cap_ - 1) % cap_;
  out = data_[idx];
  return true;
}

std::shared_ptr<Channel> ParameterRegistry::create(const char* name, ParamType, size_t capacity) {
  auto ch = std::make_shared<Channel>(capacity);
  std::lock_guard<std::mutex> l(m_);
  ch_[name] = ch; return ch;
}
std::shared_ptr<Channel> ParameterRegistry::get(const char* name) {
  std::lock_guard<std::mutex> l(m_);
  auto it = ch_.find(name);
  return it == ch_.end() ? nullptr : it->second;
}
