#pragma once
#include <chrono>
#include <functional>
#include <vector>
#include "esp_timer.h"

namespace app::sched {

using Action = std::function<void()>;
/** Minimal cron spec placeholder:
 *  - Supports strings like "@every 10s" or "@every 100ms"
 *  - TODO: support "* * * * *" style (minute-level) if needed.
 */
struct CronSpec { const char* spec{nullptr}; };

class Scheduler {
public:
  /** Schedule a repeating action with period >= 1ms. */
  bool scheduleEvery(std::chrono::milliseconds period, Action a);

  /** Schedule by cron-like spec (currently supports "@every <Ns|ms>"). */
  bool scheduleCron(const CronSpec& spec, Action a);

  ~Scheduler();

private:
  struct Item { esp_timer_handle_t h; Action a; };
  static void thunk(void* arg);
  std::vector<Item> timers_;
};

} // namespace app::sched
