#include "events/event_bus.hpp"
#include <algorithm>
#include "esp_log.h"

using namespace app::events;

static const char* TAG = "EventBus";

bool EventBus::begin(size_t depth) {
  if (q_) return true;
  q_ = xQueueCreate(depth, sizeof(Event));
  if (!q_) return false;
  xTaskCreatePinnedToCore(&EventBus::dispatchTaskThunk, TAG, 4096, this, 5, &task_, tskNO_AFFINITY);
  return task_ != nullptr;
}

bool EventBus::publish(const Event& e, TickType_t timeout) {
  if (!q_) return false;
  if (xQueueSend(q_, &e, timeout) != pdTRUE) {
    // Drop-newest policy; increment drop count
    drops_++;
    return false;
  }
  return true;
}

int EventBus::subscribe(EventType t, EventHandler cb) {
  std::lock_guard<std::mutex> lock(m_);
  int id = next_sub_id_++;
  subs_by_id_[id] = {t, std::move(cb)};
  subs_by_type_[t].push_back(id);
  return id;
}

void EventBus::unsubscribe(int id) {
  std::lock_guard<std::mutex> lock(m_);
  auto it = subs_by_id_.find(id);
  if (it == subs_by_id_.end()) return;
  auto t = it->second.first;
  subs_by_id_.erase(it);
  auto& vec = subs_by_type_[t];
  vec.erase(std::remove(vec.begin(), vec.end(), id), vec.end());
}

void EventBus::dispatchTaskThunk(void* arg) {
  static_cast<EventBus*>(arg)->dispatchTask();
}

void EventBus::dispatchTask() {
  Event e{};
  for (;;) {
    if (xQueueReceive(q_, &e, portMAX_DELAY) == pdTRUE) {
      fanout(e);
    }
  }
}

void EventBus::fanout(const Event& e) {
  std::vector<EventHandler> handlers;
  {
    std::lock_guard<std::mutex> lock(m_);
    auto it = subs_by_type_.find(e.type);
    if (it != subs_by_type_.end()) {
      handlers.reserve(it->second.size());
      for (int id : it->second) handlers.push_back(subs_by_id_[id].second);
    }
  }
  for (auto& h : handlers) { h(e); }
}
