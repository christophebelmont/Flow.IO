#pragma once
// Convenience umbrella include for users including this repo as a submodule.
#include "app/application_manager.hpp"
