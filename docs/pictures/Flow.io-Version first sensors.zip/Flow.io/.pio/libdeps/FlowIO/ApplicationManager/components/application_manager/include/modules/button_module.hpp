#pragma once
#include "modules/module.hpp"
#include "io/pin_manager.hpp"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

namespace app::modules {

struct ButtonConfig { gpio_num_t pin; bool pullup{true}; bool active_low{true}; };

/** Debounced button using periodic poll (ISR TODO). Publishes ButtonPressed/Released. */
class ButtonModule : public Module {
public:
  explicit ButtonModule(ModuleId id, const ButtonConfig& cfg);
  bool init() override;
  bool start() override;
  void stop() override;
  ModuleDescriptor descriptor() const override;

private:
  ModuleId id_;
  ButtonConfig cfg_;
  bool last_{false};
  bool running_{false};
  app::io::PinManager* pins_{nullptr};
  app::events::EventBus* bus_{nullptr};
  TaskHandle_t task_{nullptr};

  static void taskThunk(void* arg);
  void taskLoop();
};

} // namespace app::modules
