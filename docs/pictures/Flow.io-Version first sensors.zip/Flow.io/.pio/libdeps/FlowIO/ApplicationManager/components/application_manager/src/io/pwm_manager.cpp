#include "io/pwm_manager.hpp"
#include <algorithm>

using namespace app::io;

std::optional<PwmChannel> PwmManager::allocate(gpio_num_t pin, double freq_hz) {
  std::lock_guard<std::mutex> lock(m_);
  if (by_pin_.count(pin)) return by_pin_[pin];

  // Configure/reuse a low-speed LEDC timer
  ledc_timer_config_t tcfg{};
  tcfg.speed_mode       = LEDC_LOW_SPEED_MODE;
  tcfg.timer_num        = static_cast<ledc_timer_t>(timer_id_);
  tcfg.duty_resolution  = LEDC_TIMER_13_BIT;
  tcfg.freq_hz          = static_cast<uint32_t>(freq_hz);
  tcfg.clk_cfg          = LEDC_AUTO_CLK;
  ledc_timer_config(&tcfg); // ignore conflict if already set

  int ch = next_channel_++;
  if (ch >= LEDC_CHANNEL_MAX) return std::nullopt;

  ledc_channel_config_t ccfg{};
  ccfg.gpio_num   = pin;
  ccfg.speed_mode = LEDC_LOW_SPEED_MODE;
  ccfg.channel    = static_cast<ledc_channel_t>(ch);
  ccfg.intr_type  = LEDC_INTR_DISABLE;
  ccfg.timer_sel  = static_cast<ledc_timer_t>(timer_id_);
  ccfg.duty       = 0;
  ccfg.hpoint     = 0;
  if (ledc_channel_config(&ccfg) != ESP_OK) return std::nullopt;

  PwmChannel out{ch, timer_id_, pin, freq_hz};
  by_pin_[pin] = out;
  return out;
}

bool PwmManager::setDuty(const PwmChannel& ch, double duty_0_1) {
  auto duty = (uint32_t)(std::max(0.0, std::min(1.0, duty_0_1)) * ((1<<13)-1));
  if (ledc_set_duty(LEDC_LOW_SPEED_MODE, (ledc_channel_t)ch.channel, duty) != ESP_OK) return false;
  return ledc_update_duty(LEDC_LOW_SPEED_MODE, (ledc_channel_t)ch.channel) == ESP_OK;
}

void PwmManager::free(const PwmChannel& ch) {
  std::lock_guard<std::mutex> lock(m_);
  ledc_stop(LEDC_LOW_SPEED_MODE, (ledc_channel_t)ch.channel, 0);
  by_pin_.erase(ch.pin);
}
