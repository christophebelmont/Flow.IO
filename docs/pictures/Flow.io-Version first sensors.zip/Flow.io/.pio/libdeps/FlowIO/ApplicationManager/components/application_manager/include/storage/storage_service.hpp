#pragma once
#include <string>
#include <vector>

namespace app::storage {

/** NVS + FS (SPIFFS/LittleFS) helpers + safe file writes. */
class StorageService {
public:
  bool beginNvs();
  bool beginFs(); // SPIFFS or LittleFS based on Kconfig

  bool nvsSetStr(const char* ns, const char* key, const char* val);
  bool nvsGetStr(const char* ns, const char* key, std::string& out) const;

  bool writeFile(const char* path, const uint8_t* data, size_t len);
  bool readFile(const char* path, std::vector<uint8_t>& out) const;
};

} // namespace app::storage
