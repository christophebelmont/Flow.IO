#pragma once
#include <typeindex>
#include <typeinfo>
#include <unordered_map>
#include <memory>
#include <mutex>
#include <string>

/** Typed DI container for singletons. */
namespace app {

class ServiceRegistry {
public:
  template<typename T>
  void set(std::shared_ptr<T> svc) {
    std::lock_guard<std::mutex> lock(m_);
    map_[std::type_index(typeid(T))] = std::move(svc);
  }

  template<typename T>
  std::shared_ptr<T> get() const {
    std::lock_guard<std::mutex> lock(m_);
    auto it = map_.find(std::type_index(typeid(T)));
    if (it == map_.end()) return nullptr;
    return std::static_pointer_cast<T>(it->second);
  }

  /** Return textual dump of registered service types (for diagnostics). */
  std::string describe() const;

private:
  mutable std::mutex m_;
  std::unordered_map<std::type_index, std::shared_ptr<void>> map_;
};

} // namespace app
