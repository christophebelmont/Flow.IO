#include "rules/rule_engine.hpp"
#include "logging/log.hpp"

using namespace app::rules;

bool RuleEngine::loadFromJson(const char* path) {
  // TODO: parse JSON file with light-weight reader
  (void)path;
  return true;
}

void RuleEngine::onEvent(const app::events::Event& e) {
  // TODO: evaluate rules listening to events
  (void)e;
}

void RuleEngine::onStateChanged(const char* key) {
  // TODO: evaluate state-based conditions
  (void)key;
}
