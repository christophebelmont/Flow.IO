#include "logging/log.hpp"
#include <cstdarg>

using namespace app::logging;

static void vlog(esp_log_level_t lvl, const char* tag, const char* fmt, va_list ap) {
  esp_log_writev(lvl, tag, fmt, ap);
}

void Log::i(const char* tag, const char* fmt, ...) {
  va_list ap; va_start(ap, fmt); vlog(ESP_LOG_INFO, tag, fmt, ap); va_end(ap);
}
void Log::w(const char* tag, const char* fmt, ...) {
  va_list ap; va_start(ap, fmt); vlog(ESP_LOG_WARN, tag, fmt, ap); va_end(ap);
}
void Log::e(const char* tag, const char* fmt, ...) {
  va_list ap; va_start(ap, fmt); vlog(ESP_LOG_ERROR, tag, fmt, ap); va_end(ap);
}
