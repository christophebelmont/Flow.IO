#include "diag/health.hpp"
#include "esp_heap_caps.h"
#include "events/event_bus.hpp" // for drops()

using namespace app::diag;

void Health::sample() {
  last_.free_heap = heap_caps_get_free_size(MALLOC_CAP_DEFAULT);
  last_.min_free_heap = heap_caps_get_minimum_free_size(MALLOC_CAP_DEFAULT);
  // event_queue_drops is intended to be fed by EventBus; leave 0 here.
  last_.event_queue_drops = 0;
}
