#pragma once
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

namespace app::params {

enum class ParamType { Int64, Double, Bool };

struct ParamSample {
  int64_t ts_us_app{0};
  int64_t ts_rt{0};
  double  value{0};
};

/** Lock-free goal; current impl uses a small mutex (TODO: ring buffer without locks). */
class Channel {
public:
  explicit Channel(size_t capacity) : cap_(capacity), data_(capacity) {}
  bool push(double v, int64_t ts_us_app, int64_t ts_rt = 0);
  bool readLatest(ParamSample& out) const;

private:
  size_t cap_;
  mutable std::mutex m_;
  std::vector<ParamSample> data_;
  size_t head_{0};
  bool any_{false};
};

class ParameterRegistry {
public:
  std::shared_ptr<Channel> create(const char* name, ParamType, size_t capacity = 512);
  std::shared_ptr<Channel> get(const char* name);
private:
  std::mutex m_;
  std::unordered_map<std::string, std::shared_ptr<Channel>> ch_;
};

} // namespace app::params
