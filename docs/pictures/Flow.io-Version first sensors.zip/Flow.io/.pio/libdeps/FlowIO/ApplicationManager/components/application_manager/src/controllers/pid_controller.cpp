#include "controllers/pid_controller.hpp"
#include <algorithm>

using namespace app::controllers;

PidController::PidController(const PidConfig& cfg) : c_(cfg) {}

void PidController::setEnabled(bool en) {
  enabled_ = en;
  if (!en) { i_term_ = 0; out_ = 0; first_ = true; }
}

void PidController::setSetpoint(double sp) { sp_ = sp; }

void PidController::onSample(double meas, int64_t) {
  if (!enabled_) { out_ = 0; return; }
  double err = sp_ - meas;
  if (first_) { last_meas_ = meas; first_ = false; }

  // PI
  double p = c_.kp * err;
  i_term_ += c_.ki * err * c_.sample_s;
  // Anti-windup (clamp integral)
  double out_unclamped = p + i_term_;
  if (out_unclamped > c_.out_max) i_term_ -= (out_unclamped - c_.out_max);
  if (out_unclamped < c_.out_min) i_term_ -= (out_unclamped - c_.out_min);

  // D on measurement (default): -kd * d(meas)/dt
  double d = 0;
  if (c_.kd != 0) d = (c_.d_on_meas ? (-c_.kd * (meas - last_meas_) / c_.sample_s)
                                    : ( c_.kd * (err  - (sp_ - last_meas_)) / c_.sample_s));
  last_meas_ = meas;

  out_ = std::clamp(p + i_term_ + d, c_.out_min, c_.out_max);
}

double PidController::lastOutput() const { return out_; }
