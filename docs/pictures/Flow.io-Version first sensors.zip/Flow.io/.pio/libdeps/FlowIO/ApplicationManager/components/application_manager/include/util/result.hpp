#pragma once
#include <string>
#include <utility>

namespace app::util {

/** Lightweight result carrying ok flag + message. */
struct Result {
  bool ok{true};
  std::string msg;
  static Result Ok() { return {true, {}}; }
  static Result Err(std::string m) { return {false, std::move(m)}; }
};

} // namespace app::util
