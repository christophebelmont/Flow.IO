#pragma once
#include <cstdint>
#include "esp_log.h"

namespace app::logging {

/** Structured log wrapper (can later add sinks/ring buffer). */
class Log {
public:
  static void i(const char* tag, const char* fmt, ...) __attribute__((format(printf,2,3)));
  static void w(const char* tag, const char* fmt, ...) __attribute__((format(printf,2,3)));
  static void e(const char* tag, const char* fmt, ...) __attribute__((format(printf,2,3)));
};

} // namespace app::logging
