#pragma once
#include <string>
#include <vector>
#include "events/event_bus.hpp"

namespace app::rules {

struct Rule { std::string name; std::string when_expr; std::vector<std::string> actions; };

/** Minimal rule engine skeleton; expression parser is TODO. */
class RuleEngine {
public:
  bool loadFromJson(const char* path);
  void onEvent(const app::events::Event& e);
  void onStateChanged(const char* key);

private:
  // TODO: tiny expression evaluator and action dispatch
  std::vector<Rule> rules_;
};

} // namespace app::rules
