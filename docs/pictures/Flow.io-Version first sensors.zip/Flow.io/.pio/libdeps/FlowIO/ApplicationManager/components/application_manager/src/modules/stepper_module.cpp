#include "modules/stepper_module.hpp"

// Inline implementation in header (stub).
