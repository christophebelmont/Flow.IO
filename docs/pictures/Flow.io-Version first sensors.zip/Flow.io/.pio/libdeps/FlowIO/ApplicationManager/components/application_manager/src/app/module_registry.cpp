#include "app/module_registry.hpp"

using namespace app;

void ModuleRegistry::registerFactory(const std::string& key, Factory f) {
  factories_[key] = std::move(f);
}

modules::Module* ModuleRegistry::create(const std::string& key) {
  auto it = factories_.find(key);
  if (it == factories_.end()) return nullptr;
  auto m = it->second();
  auto raw = m.get();
  modules_.push_back(std::move(m));
  return raw;
}

void ModuleRegistry::add(std::unique_ptr<modules::Module> m) {
  modules_.push_back(std::move(m));
}
