# ApplicationManager (ESP-IDF v5.x / ESP32-S3)

ApplicationManager is a compact, component-oriented C++17 framework that bootstraps a full application stack for ESP-IDF targets. It gives you a root orchestrator, dependency-injected services, a module system, scheduling, telemetry primitives, storage helpers, and tested examples so you can focus on the behaviour of your device rather than re-writing glue code.

The library is shipped as a reusable ESP-IDF component and is ready for ESP32-S3 with ESP-IDF v5.x. Extend it with your own modules or controllers as your project grows.

## Quick start

1. Pull the component into an ESP-IDF workspace and select the ESP32-S3 target.
2. Build one of the examples or your own application entry point:

   ```sh
   # Example: run the PID-based thermostat demo
   cd examples/basic_thermostat
   idf.py set-target esp32s3
   idf.py build flash monitor
   ```

3. To switch the filesystem implementation, open `menuconfig` → `ApplicationManager options` and toggle **Use LittleFS**. When LittleFS is enabled, update `partitions.csv` so the `storage` partition uses the `data,littlefs` type.

The `test` folder contains a Unity-based sanity check that covers the pin manager, state store, and PID controller if you want a lightweight regression run inside ESP-IDF's unit-test app.

## Architecture overview

The orchestrator follows a deterministic boot lifecycle and wires together a set of singletons (services) and modules that encapsulate hardware-facing responsibilities.

### Boot lifecycle

`earlyInit()` → `initServices()` → `loadConfig()` → `start()` → `run()`【F:ApplicationManager/components/application_manager/include/app/application_manager.hpp†L17-L41】【F:ApplicationManager/components/application_manager/src/app/application_manager.cpp†L31-L106】

* **earlyInit** mounts storage and readies NVS/FS so configuration files and persistent data are available immediately.【F:ApplicationManager/components/application_manager/src/app/application_manager.cpp†L39-L50】
* **initServices** instantiates the dependency-injected service registry and module registry, registers all core services, and logs what is available.【F:ApplicationManager/components/application_manager/src/app/application_manager.cpp†L52-L76】
* **loadConfig** pulls JSON from `/spiffs/config.json`, validates it, and reports whether a restart is required after applying settings.【F:ApplicationManager/components/application_manager/src/app/application_manager.cpp†L78-L98】【F:ApplicationManager/components/application_manager/src/config/config_service.cpp†L9-L69】
* **start** brings up the EventBus dispatcher, starts every registered module, and primes the scheduler.【F:ApplicationManager/components/application_manager/src/app/application_manager.cpp†L100-L120】
* **run** executes a supervision loop that can host watchdog hooks and currently records system health snapshots.【F:ApplicationManager/components/application_manager/src/app/application_manager.cpp†L122-L132】【F:ApplicationManager/components/application_manager/src/diag/health.cpp†L7-L12】

### Core services

All services are stored in a thread-safe registry (`ServiceRegistry`) so modules and higher-level code can look them up without global singletons of their own.【F:ApplicationManager/components/application_manager/include/app/service_registry.hpp†L12-L34】 The following services are created during `initServices()`:

| Service | Purpose |
| --- | --- |
| `EventBus` | FreeRTOS-queue-backed publish/subscribe system with a dispatcher task. Non-blocking publishes drop on overflow and increment a drop counter for diagnostics.【F:ApplicationManager/components/application_manager/include/events/event_bus.hpp†L15-L58】【F:ApplicationManager/components/application_manager/src/events/event_bus.cpp†L10-L70】 |
| `StateStore` | Typed key-value store supporting bool/int/double/string/JSON values with edge-triggered watchers so modules can react to changes.【F:ApplicationManager/components/application_manager/include/state/state_store.hpp†L11-L49】【F:ApplicationManager/components/application_manager/src/state/state_store.cpp†L5-L52】 |
| `ClockService` | Provides monotonic timestamps (`nowAppUs`) and stores real-time clock data when available (e.g., SNTP).【F:ApplicationManager/components/application_manager/include/clock/clock_service.hpp†L8-L20】【F:ApplicationManager/components/application_manager/src/clock/clock_service.cpp†L4-L7】 |
| `Scheduler` | esp_timer-backed recurring task scheduler with support for `scheduleEvery()` and a minimal `@every <interval>` cron parser.【F:ApplicationManager/components/application_manager/include/sched/scheduler.hpp†L9-L33】【F:ApplicationManager/components/application_manager/src/sched/scheduler.cpp†L12-L49】 |
| `PinManager` | Centralised GPIO ownership manager to prevent conflicts. Handles configuration, read/write helpers, and keeps track of claim owners for debugging.【F:ApplicationManager/components/application_manager/include/io/pin_manager.hpp†L9-L35】【F:ApplicationManager/components/application_manager/src/io/pin_manager.cpp†L5-L40】 |
| `BusManager` | Reference-counted access to I²C/SPI/UART peripherals so multiple modules can safely share them.【F:ApplicationManager/components/application_manager/include/io/bus_manager.hpp†L11-L26】【F:ApplicationManager/components/application_manager/src/io/bus_manager.cpp†L5-L12】 |
| `PwmManager` | LEDC PWM allocator that binds pins to channels, manages duty updates, and frees resources cleanly.【F:ApplicationManager/components/application_manager/include/io/pwm_manager.hpp†L11-L27】【F:ApplicationManager/components/application_manager/src/io/pwm_manager.cpp†L7-L42】 |
| `StorageService` | Wraps NVS initialisation, mounts SPIFFS or LittleFS (selectable via Kconfig), and provides atomic file write helpers (`temp → fsync → rename`).【F:ApplicationManager/components/application_manager/include/storage/storage_service.hpp†L7-L16】【F:ApplicationManager/components/application_manager/src/storage/storage_service.cpp†L19-L77】 |
| `ConfigService` | Loads, saves, and validates cJSON-based configuration blobs and tracks whether changes require a reboot.【F:ApplicationManager/components/application_manager/include/config/config_service.hpp†L7-L27】【F:ApplicationManager/components/application_manager/src/config/config_service.cpp†L9-L69】 |
| `ParameterRegistry` | Lightweight telemetry channels that buffer numeric samples (timestamped) for later inspection or streaming.【F:ApplicationManager/components/application_manager/include/params/parameter_registry.hpp†L12-L38】【F:ApplicationManager/components/application_manager/src/params/parameter_registry.cpp†L5-L31】 |

Additional utilities include a structured logger (`logging::Log`) and health sampler (`diag::Health`) for periodic observability.【F:ApplicationManager/components/application_manager/include/logging/log.hpp†L7-L15】【F:ApplicationManager/components/application_manager/include/diag/health.hpp†L7-L17】 Rule-driven behaviours are scaffolded via `rules::RuleEngine`, which currently loads rule metadata and awaits a future expression evaluator.【F:ApplicationManager/components/application_manager/include/rules/rule_engine.hpp†L7-L25】

### Module system

Modules encapsulate hardware-facing behaviour and are owned by the `ModuleRegistry`, which maintains factories and lifetimes.【F:ApplicationManager/components/application_manager/include/app/module_registry.hpp†L12-L34】 Each module implements the `Module` interface (`init`, `start`, `stop`, `onEvent`, `tick`) and advertises metadata through `ModuleDescriptor`.【F:ApplicationManager/components/application_manager/include/modules/module.hpp†L9-L24】

The default starter set demonstrates typical patterns:

* **ButtonModule** – Polls a claimed GPIO with optional pull-up, debounces in a FreeRTOS task, and publishes `ButtonPressed`/`ButtonReleased` events carrying module IDs.【F:ApplicationManager/components/application_manager/include/modules/button_module.hpp†L11-L35】【F:ApplicationManager/components/application_manager/src/modules/button_module.cpp†L12-L70】
* **LedModule** – Controls either a digital output or a PWM-driven LEDC channel with safe claim/release semantics.【F:ApplicationManager/components/application_manager/include/modules/led_module.hpp†L11-L39】【F:ApplicationManager/components/application_manager/src/modules/led_module.cpp†L7-L37】
* **HeaterModule** – Wraps a PWM actuator with duty clamping for physical heaters or other power stages.【F:ApplicationManager/components/application_manager/include/modules/heater_module.hpp†L11-L32】【F:ApplicationManager/components/application_manager/src/modules/heater_module.cpp†L7-L33】
* **RotaryEncoderModule / StepperModule** – Provide stubs that reserve IDs and highlight where future PCNT/RMT-based implementations will land.【F:ApplicationManager/components/application_manager/include/modules/rotary_encoder_module.hpp†L7-L20】【F:ApplicationManager/components/application_manager/include/modules/stepper_module.hpp†L7-L20】

To add your own module:

1. Derive from `app::modules::Module` and define a descriptor.
2. In `init()`, acquire shared services (pins, buses, storage, etc.) via `ApplicationManager::instance().services()` and claim any hardware resources.
3. In `start()`, spawn tasks or register event subscriptions as needed. Keep ISR work minimal—push to queues or the EventBus.
4. Use `onEvent()`/`tick()` hooks to respond to system activity, emit new events, or update the `StateStore` and `ParameterRegistry`.
5. In `stop()`, release hardware claims and leave outputs in a safe state.

### Controllers and control loops

Controllers implement `ControllerBase` and typically run inside a scheduler callback or dedicated FreeRTOS task.【F:ApplicationManager/components/application_manager/include/controllers/controller_base.hpp†L7-L16】 The included `PidController` supports proportional/integral/derivative gains, sample-time configuration, clamped integral anti-windup, and bumpless transfer when re-enabled.【F:ApplicationManager/components/application_manager/include/controllers/pid_controller.hpp†L7-L32】【F:ApplicationManager/components/application_manager/src/controllers/pid_controller.cpp†L1-L63】 Upcoming enhancements include derivative filtering and back-calculation anti-windup (see TODOs in code).

### Events, state, and telemetry

* **Events** – Publish lightweight structs with timestamps, module IDs, and numeric slots. Subscribe per event type and manage handles to unsubscribe when cleaning up.【F:ApplicationManager/components/application_manager/include/events/event_bus.hpp†L15-L58】 The EventBus dispatcher runs in its own task to avoid blocking publishers.【F:ApplicationManager/components/application_manager/src/events/event_bus.cpp†L15-L63】
* **State** – Store configuration flags, sensor readings, or derived values in the `StateStore`. Watchers receive edge notifications outside the internal mutex so callbacks stay responsive.【F:ApplicationManager/components/application_manager/include/state/state_store.hpp†L11-L49】【F:ApplicationManager/components/application_manager/src/state/state_store.cpp†L34-L52】
* **Parameters** – Use the `ParameterRegistry` to create ring buffers for sampled telemetry (e.g., temperatures, voltages). Each channel stores timestamped `double` samples and can be consumed by diagnostics tasks or external transports.【F:ApplicationManager/components/application_manager/include/params/parameter_registry.hpp†L12-L38】【F:ApplicationManager/components/application_manager/src/params/parameter_registry.cpp†L5-L31】

### Storage and configuration

The `StorageService` initialises NVS and mounts SPIFFS or LittleFS under `/spiffs`. It offers helpers for atomic file writes (`writeFile`) and typed NVS operations so configuration and calibration data survive power cycles.【F:ApplicationManager/components/application_manager/include/storage/storage_service.hpp†L7-L16】【F:ApplicationManager/components/application_manager/src/storage/storage_service.cpp†L19-L77】 `ConfigService` reads and validates `config.json` using cJSON, writes updates safely, and tracks whether changes require a reboot (for example, when hardware mappings change).【F:ApplicationManager/components/application_manager/include/config/config_service.hpp†L7-L27】【F:ApplicationManager/components/application_manager/src/config/config_service.cpp†L9-L69】

### Diagnostics and observability

* `diag::Health` samples heap usage and (future) EventBus drop statistics so the supervisor loop can report or act on system strain.【F:ApplicationManager/components/application_manager/include/diag/health.hpp†L7-L17】【F:ApplicationManager/components/application_manager/src/diag/health.cpp†L7-L12】
* `logging::Log` is a thin wrapper over `ESP_LOGx` that exists so you can later swap in additional sinks (ring buffers, remote logging) without touching call sites.【F:ApplicationManager/components/application_manager/include/logging/log.hpp†L7-L15】

## Example: PID thermostat application

The `examples/basic_thermostat` project demonstrates how the pieces fit together in a real application entry point.【F:ApplicationManager/examples/basic_thermostat/main/main.cpp†L1-L77】 It:

1. Calls the orchestrator lifecycle (`earlyInit`, `initServices`, `registerDefaultModules`).
2. Subscribes to `ButtonPressed` events to toggle a `StateStore` flag.
3. Creates a telemetry channel for temperature samples.
4. Configures a `PidController` that drives the `HeaterModule` and simulates room temperature dynamics every 500 ms via the `Scheduler`.
5. Starts and runs the application loop.

Use this as a template for your own application by replacing the simulated physics with real sensor readings and actuators.

## Safety and best practices

* Claim GPIO, PWM channels, and buses exclusively through the provided managers. Avoid calling `gpio_set_level`, `ledc_*`, or `i2c_*` directly from modules you do not control.
* Define safe shutdown states in every module's `stop()` method and release resources before returning.【F:ApplicationManager/components/application_manager/include/modules/button_module.hpp†L22-L35】【F:ApplicationManager/components/application_manager/include/modules/led_module.hpp†L21-L39】
* Keep interrupt handlers short—defer work to tasks via queues or the EventBus.
* Monitor `diag::Health::last()` and the EventBus drop counter to catch overload situations early.【F:ApplicationManager/components/application_manager/include/diag/health.hpp†L7-L17】【F:ApplicationManager/components/application_manager/include/events/event_bus.hpp†L51-L57】

## Roadmap & TODO markers

The codebase is annotated with clear TODOs for future enhancements:

* Expression parser and action executor for `rules::RuleEngine`.
* Extended cron parser and one-shot scheduling in `Scheduler`.
* Lock-free ring buffer for `ParameterRegistry::Channel`.
* ISR-based button debounce, full rotary encoder (PCNT), and stepper (RMT/PCNT) implementations.
* PID improvements (derivative filtering, back-calculation anti-windup).

These markers are intentionally left in place to guide contributors toward the next steps.

---

ApplicationManager compiles out-of-the-box on ESP-IDF v5.x and provides a clean foundation for orchestrating complex embedded applications with predictable lifecycles and discoverable services.
