#pragma once
#include <cstdint>
#include <mutex>
#include <unordered_map>
#include "driver/i2c.h"
#include "driver/uart.h"
#include "driver/spi_master.h"

namespace app::io {

/** Ref-counted descriptors for I2C/SPI/UART to avoid double-use. */
class BusManager {
public:
  bool refI2C(i2c_port_t port);
  void unrefI2C(i2c_port_t port);

  bool refSPI(spi_host_device_t host);
  void unrefSPI(spi_host_device_t host);

  bool refUART(uart_port_t port);
  void unrefUART(uart_port_t port);

private:
  mutable std::mutex m_;
  std::unordered_map<int, int> i2c_refs_, spi_refs_, uart_refs_;
};

} // namespace app::io
