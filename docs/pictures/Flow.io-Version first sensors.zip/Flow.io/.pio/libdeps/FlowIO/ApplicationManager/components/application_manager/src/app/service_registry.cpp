#include "app/service_registry.hpp"
#include <sstream>

using namespace app;

std::string ServiceRegistry::describe() const {
  std::lock_guard<std::mutex> lock(m_);
  std::stringstream ss;
  ss << "Services: " << map_.size();
  return ss.str();
}
