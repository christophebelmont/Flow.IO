#include "unity.h"
#include "io/pin_manager.hpp"
#include "state/state_store.hpp"
#include "controllers/pid_controller.hpp"

extern "C" void app_main(void)
{
  UNITY_BEGIN();

  // PinManager claim/release
  {
    app::io::PinManager pins;
    TEST_ASSERT_TRUE(pins.claim({GPIO_NUM_1, app::io::PinMode::Output, "T"}));
    TEST_ASSERT_FALSE(pins.claim({GPIO_NUM_1, app::io::PinMode::Output, "U"}));
    pins.release(GPIO_NUM_1);
    TEST_ASSERT_TRUE(pins.claim({GPIO_NUM_1, app::io::PinMode::Output, "V"}));
  }

  // StateStore set/get/watch
  {
    app::state::StateStore st;
    bool called=false;
    st.watch("x", [&](const char*){ called=true; });
    TEST_ASSERT_TRUE(st.setInt("x", 42));
    int64_t v=0; TEST_ASSERT_TRUE(st.getInt("x", v));
    TEST_ASSERT_EQUAL_INT64(42, v);
    TEST_ASSERT_TRUE(called);
  }

  // PID step response skeleton
  {
    app::controllers::PidConfig pc{.kp=1.0,.ki=0.2,.kd=0,.out_min=0,.out_max=1,.sample_s=0.1};
    app::controllers::PidController pid(pc);
    pid.setEnabled(true); pid.setSetpoint(1.0);
    double meas=0;
    for (int i=0;i<20;i++){ pid.onSample(meas, 0); meas += 0.2*pid.lastOutput(); }
    TEST_ASSERT_TRUE(pid.lastOutput() <= 1.0 && pid.lastOutput() >= 0.0);
  }

  UNITY_END();
}
