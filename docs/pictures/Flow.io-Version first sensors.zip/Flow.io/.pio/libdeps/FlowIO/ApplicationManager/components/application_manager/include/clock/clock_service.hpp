#pragma once
#include <cstdint>
#include <ctime>

namespace app::clock {

/** Wall/app time provider with NTP sync support (stubbed). */
class ClockService {
public:
  /** Monotonic time since boot (us). */
  int64_t nowAppUs() const;

  /** Real wall time (seconds since epoch), 0 if unknown. */
  time_t  nowRealTime() const;

  /** Set wall time (e.g., from SNTP). */
  void    setRealTime(time_t t);

private:
  volatile time_t rt_{0};
};

} // namespace app::clock
