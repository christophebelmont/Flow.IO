#include "app/application_manager.hpp"
#include <chrono>
#include "events/event_bus.hpp"
#include "state/state_store.hpp"
#include "params/parameter_registry.hpp"
#include "controllers/pid_controller.hpp"
#include "modules/heater_module.hpp"
#include "modules/led_module.hpp"
#include "logging/log.hpp"
#include "esp_log.h"

using app::ApplicationManager;
using app::events::EventType;

extern "C" void app_main(void)
{
  auto& app = ApplicationManager::instance();
  app.earlyInit();
  app.initServices();

  // Default modules (button on GPIO0, LED on 38, heater PWM on 2)
  app.registerDefaultModules();

  // Example: subscribe to Button to toggle "enable_heat" state
  auto bus = app.services().get<app::events::EventBus>();
  auto state = app.services().get<app::state::StateStore>();
  state->setBool("enable_heat", true);
  bus->subscribe(EventType::ButtonPressed, [state](const app::events::Event&){
    bool v=false; state->getBool("enable_heat", v); state->setBool("enable_heat", !v);
    ESP_LOGI("thermo", "enable_heat toggled -> %s", (!v) ? "true" : "false");
  });

  // Parameter channel for temperature (simulated)
  auto params = app.services().get<app::params::ParameterRegistry>();
  auto temp_ch = params->create("temp_c", app::params::ParamType::Double, 128);

  // PID (simple): 0..1 output range maps to heater duty
  app::controllers::PidConfig pc{ .kp=0.4, .ki=0.05, .kd=0.0, .out_min=0.0, .out_max=1.0, .sample_s=0.5 };
  app::controllers::PidController pid(pc);
  pid.setEnabled(true);
  pid.setSetpoint(40.0); // 40°C target

  // Simulate room temp dynamics (very crude first-order), schedule @ 500ms
  auto clk = app.services().get<app::clock::ClockService>();
  double temp = 20.0; // start at 20°C
  double ambient = 20.0;

  // Identify the heater module (id=3 in our defaults)
  app::modules::HeaterModule* heater = nullptr;
  for (auto& m : app.modules().all()) {
    if (m->descriptor().id == 3) { heater = dynamic_cast<app::modules::HeaterModule*>(m.get()); break; }
  }

  auto sched = app.services().get<app::sched::Scheduler>();
  sched->scheduleEvery(std::chrono::milliseconds(500), [=]() mutable {
    // Read enable flag
    bool enable = true; state->getBool("enable_heat", enable);

    // PID sample
    pid.onSample(temp, clk->nowAppUs());

    double duty = enable ? pid.lastOutput() : 0.0;
    if (heater) heater->setDuty(duty);

    // Update simulated temperature: dT = -k*(T-Ta) + h*duty
    double k = 0.05; // loss
    double h = 2.0;  // heater effect
    temp += (-k*(temp - ambient) + h*duty) * pc.sample_s;

    temp_ch->push(temp, clk->nowAppUs());

    ESP_LOGI("thermo", "temp=%.2fC duty=%.2f enable=%d", temp, duty, enable?1:0);
  });

  // Boot complete
  app.start();
  app.run();
}
