#include "modules/button_module.hpp"
#include "app/application_manager.hpp"
#include "events/event_bus.hpp"
#include "state/state_store.hpp"
#include "clock/clock_service.hpp"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

using namespace app::modules;
using app::ApplicationManager;
using app::events::Event;
using app::events::EventType;

ButtonModule::ButtonModule(ModuleId id, const ButtonConfig& cfg) : id_(id), cfg_(cfg) {}

bool ButtonModule::init() {
  pins_ = ApplicationManager::instance().services().get<app::io::PinManager>().get();
  bus_  = ApplicationManager::instance().services().get<app::events::EventBus>().get();
  if (!pins_ || !bus_) return false;
  app::io::PinClaim c{cfg_.pin, cfg_.pullup ? app::io::PinMode::InputPullUp : app::io::PinMode::Input, "ButtonModule"};
  if (!pins_->claim(c)) return false;
  bool lvl=false; pins_->read(cfg_.pin, lvl);
  last_ = cfg_.active_low ? !lvl : lvl;
  return true;
}

bool ButtonModule::start() {
  running_ = true;
  xTaskCreatePinnedToCore(&ButtonModule::taskThunk, "btn", 2048, this, 4, &task_, tskNO_AFFINITY);
  return task_ != nullptr;
}

void ButtonModule::stop() {
  running_ = false;
  if (task_) { vTaskDelete(task_); task_ = nullptr; }
}

ModuleDescriptor ButtonModule::descriptor() const { return {id_, "button", "button"}; }

void ButtonModule::taskThunk(void* arg) { static_cast<ButtonModule*>(arg)->taskLoop(); }

void ButtonModule::taskLoop() {
  auto& clk = *ApplicationManager::instance().services().get<app::clock::ClockService>();
  for (;;) {
    if (!running_) vTaskDelay(pdMS_TO_TICKS(100));
    bool lvl=false; pins_->read(cfg_.pin, lvl);
    bool pressed = cfg_.active_low ? !lvl : lvl;
    if (pressed != last_) {
      // crude debounce
      vTaskDelay(pdMS_TO_TICKS(20));
      pins_->read(cfg_.pin, lvl);
      pressed = cfg_.active_low ? !lvl : lvl;
      if (pressed != last_) {
        last_ = pressed;
        Event e{};
        e.type = pressed ? EventType::ButtonPressed : EventType::ButtonReleased;
        e.module_id = id_;
        e.ts_us_app = clk.nowAppUs();
        bus_->publish(e);
      }
    }
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}
