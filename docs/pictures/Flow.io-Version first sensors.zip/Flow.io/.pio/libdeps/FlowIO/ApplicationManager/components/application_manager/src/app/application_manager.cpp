#include "app/application_manager.hpp"
#include "events/event_bus.hpp"
#include "state/state_store.hpp"
#include "clock/clock_service.hpp"
#include "sched/scheduler.hpp"
#include "io/pin_manager.hpp"
#include "io/bus_manager.hpp"
#include "io/pwm_manager.hpp"
#include "storage/storage_service.hpp"
#include "config/config_service.hpp"
#include "cJSON.h"
#include "params/parameter_registry.hpp"
#include "logging/log.hpp"
#include "modules/button_module.hpp"
#include "modules/led_module.hpp"
#include "modules/heater_module.hpp"
#include "modules/rotary_encoder_module.hpp"
#include "modules/stepper_module.hpp"
#include "diag/health.hpp"

#include "esp_log.h"

using namespace app;

static const char* TAG = "AppMgr";

ApplicationManager& ApplicationManager::instance() {
  static ApplicationManager inst;
  return inst;
}

void ApplicationManager::earlyInit() {
  ESP_LOGI(TAG, "earlyInit()");
  auto storage = std::make_shared<storage::StorageService>();
  storage->beginNvs();
  storage->beginFs();
}

void ApplicationManager::initServices() {
  service_registry_ = std::make_unique<ServiceRegistry>();
  module_registry_  = std::make_unique<ModuleRegistry>();

  service_registry_->set(std::make_shared<events::EventBus>());
  service_registry_->set(std::make_shared<state::StateStore>());
  service_registry_->set(std::make_shared<clock::ClockService>());
  service_registry_->set(std::make_shared<sched::Scheduler>());
  service_registry_->set(std::make_shared<io::PinManager>());
  service_registry_->set(std::make_shared<io::BusManager>());
  service_registry_->set(std::make_shared<io::PwmManager>());
  service_registry_->set(std::make_shared<storage::StorageService>());
  service_registry_->set(std::make_shared<config::ConfigService>());
  service_registry_->set(std::make_shared<params::ParameterRegistry>());

  ESP_LOGI(TAG, "Services ready: %s", service_registry_->describe().c_str());
}

AppConfigLoadResult ApplicationManager::loadConfig() {
  auto cfgsvc = service_registry_->get<config::ConfigService>();
  config::Config cfg{};
  AppConfigLoadResult r{true, false};
  if (!cfgsvc->load(cfg)) { ESP_LOGW(TAG, "No/invalid config.json; using defaults"); r.ok = false; }
  std::string err;
  if (!cfgsvc->validate(cfg, err)) { ESP_LOGW(TAG, "Config invalid: %s", err.c_str()); r.ok = false; }
  r.restart_required = cfgsvc->restartRequired();
  if (cfg.root) cJSON_Delete(cfg.root);
  return r;
}

void ApplicationManager::start() {
  // Start EventBus
  auto bus = service_registry_->get<events::EventBus>();
  bus->begin(64);

  // Release: modules start
  for (auto& m : module_registry_->all()) {
    if (!m->start()) ESP_LOGW(TAG, "Module start failed: %s", m->descriptor().name);
  }

  // Scheduler is timer-based; nothing else to do here.
  ESP_LOGI(TAG, "start() complete");
}

void ApplicationManager::run() {
  ESP_LOGI(TAG, "Supervisor loop running");
  auto health = diag::Health{};
  for (;;) {
    health.sample();
    vTaskDelay(pdMS_TO_TICKS(1000));
  }
}

void ApplicationManager::registerDefaultModules() {
  // Button on GPIO 0
  module_registry_->add(std::make_unique<modules::ButtonModule>(1, modules::ButtonConfig{GPIO_NUM_0, true, true}));
  module_registry_->add(std::make_unique<modules::LedModule>(2, modules::LedConfig{GPIO_NUM_38, false, 1000}));
  module_registry_->add(std::make_unique<modules::HeaterModule>(3, modules::HeaterConfig{GPIO_NUM_2, 10.0, 0.0, 1.0}));
  module_registry_->add(std::make_unique<modules::RotaryEncoderModule>(4));
  module_registry_->add(std::make_unique<modules::StepperModule>(5));

  for (auto& m : module_registry_->all()) {
    if (!m->init()) ESP_LOGW(TAG, "Module init failed: %s", m->descriptor().name);
    else ESP_LOGI(TAG, "Module ready: %s", m->descriptor().name);
  }
}
