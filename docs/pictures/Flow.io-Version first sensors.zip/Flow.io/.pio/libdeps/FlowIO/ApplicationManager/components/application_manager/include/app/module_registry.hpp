#pragma once
#include <functional>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>
#include "modules/module.hpp"

namespace app {

/** Factory registry for modules by type key; owns module instances. */
class ModuleRegistry {
public:
  using Factory = std::function<std::unique_ptr<modules::Module>()>;

  /** Register a factory function by type name/key. */
  void registerFactory(const std::string& type_key, Factory f);

  /** Instantiate a module by factory key; take ownership. */
  modules::Module* create(const std::string& type_key);

  /** Adopt an existing module instance. */
  void add(std::unique_ptr<modules::Module> m);

  /** Iterate all modules. */
  const std::vector<std::unique_ptr<modules::Module>>& all() const { return modules_; }

private:
  std::unordered_map<std::string, Factory> factories_;
  std::vector<std::unique_ptr<modules::Module>> modules_;
};

} // namespace app
