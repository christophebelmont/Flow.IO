#include "config/config_service.hpp"
#include "storage/storage_service.hpp"
#include <vector>
#include <string>
#include <cstdio>

using namespace app::config;

bool ConfigService::load(Config& out) {
  // Load from /spiffs/config.json
  std::vector<uint8_t> data;
  // Caller is expected to register StorageService in ServiceRegistry and call beginFs()
  // Here we keep it simple: use stdio directly
  FILE* f = fopen("/spiffs/config.json", "rb");
  if (!f) { out.root = nullptr; out.version = {1,0}; return true; } // default empty
  fseek(f, 0, SEEK_END); long sz = ftell(f); fseek(f, 0, SEEK_SET);
  std::vector<char> buf(sz+1, 0);
  fread(buf.data(), 1, sz, f); fclose(f);
  cJSON* root = cJSON_Parse(buf.data());
  if (!root) return false;
  cJSON* ver = cJSON_GetObjectItem(root, "config_version");
  if (ver && cJSON_IsObject(ver)) {
    out.version.major = cJSON_GetObjectItem(ver, "major")->valueint;
    out.version.minor = cJSON_GetObjectItem(ver, "minor")->valueint;
  } else {
    out.version = {1,0};
  }
  out.root = root;
  return true;
}

bool ConfigService::save(const Config& in) {
  if (!in.root) return false;
  char* text = cJSON_PrintUnformatted(in.root);
  if (!text) return false;
  bool ok = false;
  do {
    std::string tmp = "/spiffs/config.json.tmp";
    FILE* f = fopen(tmp.c_str(), "wb"); if (!f) break;
    size_t n = fwrite(text, 1, strlen(text), f);
    fflush(f); fsync(fileno(f)); fclose(f);
    if (n != strlen(text)) break;
    remove("/spiffs/config.json");
    if (rename(tmp.c_str(), "/spiffs/config.json") != 0) break;
    ok = true;
  } while (0);
  cJSON_free(text);
  return ok;
}

bool ConfigService::validate(const Config& cfg, std::string& err) {
  if (cfg.version.major < 1) { err = "unsupported config version"; return false; }
  // TODO: schema validate relevant keys
  return true;
}

bool ConfigService::markRestartRequired() { restart_required_ = true; return true; }
bool ConfigService::restartRequired() const { return restart_required_; }
