#pragma once
#include <cstdint>
#include <functional>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

namespace app::state {

enum class ValueType { Bool, Int, Double, String, Json }; // Json: TODO in a light form

struct Key { const char* name; ValueType type; };

class StateStore {
public:
  using Watcher = std::function<void(const char* key)>;

  bool setBool(const char* key, bool v);
  bool getBool(const char* key, bool& out) const;

  bool setInt(const char* key, int64_t v);
  bool getInt(const char* key, int64_t& out) const;

  bool setDouble(const char* key, double v);
  bool getDouble(const char* key, double& out) const;

  bool setString(const char* key, const std::string& v);
  bool getString(const char* key, std::string& out) const;

  // Minimal JSON placeholder (use string). TODO: integrate tiny JSON if needed.
  bool setJson(const char* key, const std::string& json);
  bool getJson(const char* key, std::string& out) const;

  /** Register a watcher for a key (edge-notification; rate-limit TODO). */
  int watch(const char* key, Watcher cb);

  /** Remove watcher by id. */
  void unwatch(int id);

private:
  void notify(const char* key);

  mutable std::mutex m_;
  std::unordered_map<std::string, bool>    b_;
  std::unordered_map<std::string, int64_t> i_;
  std::unordered_map<std::string, double>  d_;
  std::unordered_map<std::string, std::string> s_;
  std::unordered_map<std::string, std::string> j_;

  int next_id_{1};
  std::unordered_map<int, std::pair<std::string, Watcher>> watchers_;
  std::unordered_map<std::string, std::vector<int>> watchers_by_key_;
};

} // namespace app::state
