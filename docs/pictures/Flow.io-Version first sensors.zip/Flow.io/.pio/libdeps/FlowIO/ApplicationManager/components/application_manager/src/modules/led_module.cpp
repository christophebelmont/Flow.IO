#include "modules/led_module.hpp"
#include "app/application_manager.hpp"

using namespace app::modules;

LedModule::LedModule(ModuleId id, const LedConfig& cfg): id_(id), cfg_(cfg) {}

bool LedModule::init() {
  auto& reg = app::ApplicationManager::instance().services();
  pins_ = reg.get<app::io::PinManager>().get();
  pwm_  = reg.get<app::io::PwmManager>().get();
  if (!pins_ || !pwm_) return false;
  if (!cfg_.pwm) {
    owned_pin_ = pins_->claim({cfg_.pin, app::io::PinMode::Output, "LedModule"});
    return owned_pin_;
  }
  return true;
}

bool LedModule::start() {
  if (cfg_.pwm) {
    ch_ = pwm_->allocate(cfg_.pin, cfg_.pwm_freq);
    return ch_.has_value();
  }
  return true;
}

void LedModule::stop() {
  if (ch_) { pwm_->free(*ch_); ch_.reset(); }
  if (owned_pin_) { pins_->release(cfg_.pin); owned_pin_ = false; }
}

void LedModule::set(bool on) {
  if (!cfg_.pwm && pins_) pins_->write(cfg_.pin, on);
}

void LedModule::setPwm(double duty) {
  if (cfg_.pwm && ch_) pwm_->setDuty(*ch_, duty);
}

ModuleDescriptor LedModule::descriptor() const { return {id_, "led", "led"}; }
