#pragma once
#include "modules/module.hpp"

namespace app::modules {

/** Stub: stepper driver using RMT/PCNT timing (TODO). */
class StepperModule : public Module {
public:
  StepperModule(ModuleId id) : id_(id) {}
  bool init() override { return true; }
  bool start() override { return true; }
  void stop() override {}
  ModuleDescriptor descriptor() const override { return {id_, "stepper", "stepper"}; }
private:
  ModuleId id_;
};

} // namespace app::modules
