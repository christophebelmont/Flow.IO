#pragma once
#include <cstdint>
#include "events/event_bus.hpp"

namespace app::modules {

using ModuleId = uint32_t;

struct ModuleDescriptor { ModuleId id; const char* name; const char* type; };

/** Base module API with lifecycle and event hooks. */
class Module {
public:
  virtual ~Module() = default;
  virtual bool init() = 0;
  virtual bool start() = 0;
  virtual void stop() = 0;
  virtual void onEvent(const app::events::Event&) {}
  virtual void tick(int64_t ts_us) {}
  virtual ModuleDescriptor descriptor() const = 0;
};

} // namespace app::modules
