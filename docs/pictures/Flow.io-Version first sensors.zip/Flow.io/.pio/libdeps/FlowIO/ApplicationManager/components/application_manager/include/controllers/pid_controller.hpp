#pragma once
#include "controllers/controller_base.hpp"

namespace app::controllers {

struct PidConfig {
  double kp{1}, ki{0}, kd{0};
  double out_min{-1}, out_max{1};
  double sample_s{0.1};
  bool   d_on_meas{true};
};

/** PID with anti-windup (clamped integral) and bumpless transfer. */
class PidController : public ControllerBase {
public:
  explicit PidController(const PidConfig& cfg);
  void setEnabled(bool en) override;
  void setSetpoint(double sp) override;
  void onSample(double input, int64_t ts_us) override;
  double lastOutput() const override;

private:
  PidConfig c_;
  bool enabled_{false};
  double sp_{0}, last_meas_{0}, out_{0}, i_term_{0};
  bool first_{true};
  // TODO: back-calculation anti-windup and derivative filtering
};

} // namespace app::controllers
