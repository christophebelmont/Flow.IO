#include "clock/clock_service.hpp"
#include "esp_timer.h"

using namespace app::clock;
int64_t ClockService::nowAppUs() const { return esp_timer_get_time(); }
time_t  ClockService::nowRealTime() const { return rt_; }
void    ClockService::setRealTime(time_t t) { rt_ = t; }
