#include "io/pin_manager.hpp"

using namespace app::io;

bool PinManager::claim(const PinClaim& c) {
  std::lock_guard<std::mutex> lock(m_);
  if (claims_.count(c.pin)) return false;
  if (!configure(c)) return false;
  claims_[c.pin] = c;
  return true;
}

void PinManager::release(gpio_num_t pin) {
  std::lock_guard<std::mutex> lock(m_);
  claims_.erase(pin);
  // Leave config as-is (safe default), caller may reconfigure later.
}

bool PinManager::configure(const PinClaim& c) {
  gpio_config_t cfg{};
  cfg.pin_bit_mask = (1ULL << c.pin);
  switch (c.mode) {
    case PinMode::Input: cfg.mode = GPIO_MODE_INPUT; cfg.pull_up_en = GPIO_PULLUP_DISABLE; cfg.pull_down_en = GPIO_PULLDOWN_DISABLE; break;
    case PinMode::InputPullUp: cfg.mode = GPIO_MODE_INPUT; cfg.pull_up_en = GPIO_PULLUP_ENABLE; cfg.pull_down_en = GPIO_PULLDOWN_DISABLE; break;
    case PinMode::Output: cfg.mode = GPIO_MODE_OUTPUT; break;
    case PinMode::OutputOpenDrain: cfg.mode = GPIO_MODE_OUTPUT_OD; break;
  }
  return gpio_config(&cfg) == ESP_OK;
}

bool PinManager::write(gpio_num_t pin, bool level) {
  std::lock_guard<std::mutex> lock(m_);
  if (!claims_.count(pin)) return false;
  return gpio_set_level(pin, level ? 1 : 0) == ESP_OK;
}

bool PinManager::read(gpio_num_t pin, bool& level) const {
  std::lock_guard<std::mutex> lock(m_);
  if (!claims_.count(pin)) return false;
  level = gpio_get_level(pin);
  return true;
}

std::string PinManager::ownerOf(gpio_num_t pin) const {
  std::lock_guard<std::mutex> lock(m_);
  auto it = claims_.find(pin);
  return it == claims_.end() ? "" : std::string(it->second.owner ? it->second.owner : "");
}
