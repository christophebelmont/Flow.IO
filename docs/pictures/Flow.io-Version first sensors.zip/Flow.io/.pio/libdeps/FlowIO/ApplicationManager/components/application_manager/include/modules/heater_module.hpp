#pragma once
#include "modules/module.hpp"
#include "io/pwm_manager.hpp"
#include <optional>

namespace app::modules {

struct HeaterConfig { gpio_num_t pin; double pwm_freq{10}; double duty_min{0.0}, duty_max{1.0}; };

/** PWM heater actuator (LEDC). */
class HeaterModule : public Module {
public:
  explicit HeaterModule(ModuleId id, const HeaterConfig& cfg);
  bool init() override;
  bool start() override;
  void stop() override;

  /** Set duty (clamped to [duty_min,duty_max]). */
  void setDuty(double duty_0_1);

  ModuleDescriptor descriptor() const override;

private:
  ModuleId id_;
  HeaterConfig cfg_;
  app::io::PwmManager* pwm_{nullptr};
  std::optional<app::io::PwmChannel> ch_;
};

} // namespace app::modules
