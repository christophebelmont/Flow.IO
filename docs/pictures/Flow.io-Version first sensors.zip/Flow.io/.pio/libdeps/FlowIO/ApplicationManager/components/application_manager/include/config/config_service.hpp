#pragma once
#include <string>
#include "cJSON.h"

namespace app::config {

/** Simple version marker for configs. */
struct Version { int major, minor; };

/** Loaded config root and schema version (cJSON used from ESP-IDF). */
struct Config { Version version; cJSON* root; };

/** Load/validate/mark-restart API for JSON config. */
class ConfigService {
public:
  bool load(Config& out);
  bool save(const Config& in);
  bool validate(const Config& cfg, std::string& err);
  bool markRestartRequired();
  bool restartRequired() const;

private:
  bool restart_required_{false};
};

} // namespace app::config
