#pragma once
#include "modules/module.hpp"
#include "io/pin_manager.hpp"
#include "io/pwm_manager.hpp"
#include <optional>

namespace app::modules {

struct LedConfig { gpio_num_t pin; bool pwm{false}; double pwm_freq{1000}; };

class LedModule : public Module {
public:
  explicit LedModule(ModuleId id, const LedConfig& cfg);
  bool init() override;
  bool start() override;
  void stop() override;

  /** On/off (ignored if PWM mode is enabled). */
  void set(bool on);

  /** PWM duty 0..1 (allocates LEDC if needed). */
  void setPwm(double duty_0_1);

  ModuleDescriptor descriptor() const override;

private:
  ModuleId id_;
  LedConfig cfg_;
  app::io::PinManager* pins_{nullptr};
  app::io::PwmManager* pwm_{nullptr};
  std::optional<app::io::PwmChannel> ch_;
  bool owned_pin_{false};
};

} // namespace app::modules
