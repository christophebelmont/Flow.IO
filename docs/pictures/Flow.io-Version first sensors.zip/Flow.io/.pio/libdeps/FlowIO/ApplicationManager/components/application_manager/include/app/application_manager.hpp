#pragma once
#include <memory>
#include <vector>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "app/service_registry.hpp"
#include "app/module_registry.hpp"

namespace app {

/** Result of loading/validating configuration. */
struct AppConfigLoadResult { bool ok; bool restart_required; };

/**
 * @brief Application orchestrator. Owns services, registries, FreeRTOS task bring-up.
 *
 * Boot phases:
 *   earlyInit()  -> basic platform bring-up (log init, NVS, FS)
 *   initServices() -> create/register core services (EventBus, StateStore, Clock, IO, Storage, Config, Scheduler)
 *   loadConfig() -> read/validate config, apply policies
 *   start() -> spawn dispatcher/scheduler/controller tasks, start modules
 *   run() -> supervision loop (health, watchdog hooks)
 */
class ApplicationManager {
public:
  static ApplicationManager& instance();

  /** Early platform init: logging tag, NVS, FS (SPIFFS or LittleFS). */
  void earlyInit();

  /** Construct and register core services and registries. */
  void initServices();

  /** Load configuration via ConfigService; apply minimal policies. */
  AppConfigLoadResult loadConfig();

  /** Start runtime tasks: EventBus dispatch, Scheduler, (optional) Controller loop. */
  void start();

  /** Supervision loop: metrics, watchdog, low-duty orchestration. */
  void run();

  /** Register a default set of modules (Button, LED, Heater, Encoder stubs). */
  void registerDefaultModules();

  ServiceRegistry& services() { return *service_registry_; }
  ModuleRegistry&  modules()  { return *module_registry_;  }

private:
  ApplicationManager() = default;
  std::unique_ptr<ServiceRegistry> service_registry_;
  std::unique_ptr<ModuleRegistry>  module_registry_;
  TaskHandle_t eventbus_task_{nullptr};
  TaskHandle_t scheduler_task_{nullptr};

  // Non-copyable
  ApplicationManager(const ApplicationManager&) = delete;
  ApplicationManager& operator=(const ApplicationManager&) = delete;
};

} // namespace app
