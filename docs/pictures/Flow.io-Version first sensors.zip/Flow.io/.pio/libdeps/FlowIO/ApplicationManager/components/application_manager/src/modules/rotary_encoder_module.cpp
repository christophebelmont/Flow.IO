#include "modules/rotary_encoder_module.hpp"

// Inline implementation in header (stub).
