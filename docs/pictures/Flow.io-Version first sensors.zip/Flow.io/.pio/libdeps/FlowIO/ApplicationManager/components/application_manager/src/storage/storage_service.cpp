#include "storage/storage_service.hpp"
#include <cstring>
#include <cstdio>
#include <vector>
#include <string>
#include <unistd.h>
#include "esp_err.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "esp_vfs.h"
#include "esp_spiffs.h"
#if CONFIG_APP_USE_LITTLEFS
#include "esp_littlefs.h"
#endif

using namespace app::storage;
static const char* TAG = "Storage";

bool StorageService::beginNvs() {
  esp_err_t err = nvs_flash_init();
  if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    ESP_ERROR_CHECK(nvs_flash_erase());
    err = nvs_flash_init();
  }
  return err == ESP_OK;
}

bool StorageService::beginFs() {
#if CONFIG_APP_USE_LITTLEFS
  esp_vfs_littlefs_conf_t conf = {};
  conf.base_path = "/spiffs";     // keep mount point uniform
  conf.partition_label = "storage";
  conf.format_if_mount_failed = true;
  esp_err_t err = esp_vfs_littlefs_register(&conf);
  return err == ESP_OK;
#else
  esp_vfs_spiffs_conf_t conf = {};
  conf.base_path = "/spiffs";
  conf.partition_label = "storage";
  conf.max_files = 8;
  conf.format_if_mount_failed = true;
  esp_err_t err = esp_vfs_spiffs_register(&conf);
  return err == ESP_OK;
#endif
}

bool StorageService::nvsSetStr(const char* ns, const char* key, const char* val) {
  nvs_handle_t h;
  if (nvs_open(ns, NVS_READWRITE, &h) != ESP_OK) return false;
  esp_err_t err = nvs_set_str(h, key, val);
  nvs_commit(h);
  nvs_close(h);
  return err == ESP_OK;
}

bool StorageService::nvsGetStr(const char* ns, const char* key, std::string& out) const {
  nvs_handle_t h;
  size_t len = 0;
  if (nvs_open(ns, NVS_READONLY, &h) != ESP_OK) return false;
  if (nvs_get_str(h, key, nullptr, &len) != ESP_OK || len == 0) { nvs_close(h); return false; }
  std::vector<char> buf(len);
  if (nvs_get_str(h, key, buf.data(), &len) != ESP_OK) { nvs_close(h); return false; }
  nvs_close(h);
  out.assign(buf.data());
  return true;
}

bool StorageService::writeFile(const char* path, const uint8_t* data, size_t len) {
  std::string tmp = std::string(path) + ".tmp";
  FILE* f = fopen(tmp.c_str(), "wb");
  if (!f) return false;
  if (fwrite(data, 1, len, f) != len) { fclose(f); return false; }
  fflush(f);
  fsync(fileno(f));
  fclose(f);
  remove(path); // ignore if not exists
  return rename(tmp.c_str(), path) == 0;
}

bool StorageService::readFile(const char* path, std::vector<uint8_t>& out) const {
  FILE* f = fopen(path, "rb");
  if (!f) return false;
  fseek(f, 0, SEEK_END);
  long sz = ftell(f);
  fseek(f, 0, SEEK_SET);
  out.resize(sz);
  size_t r = fread(out.data(), 1, sz, f);
  fclose(f);
  return r == (size_t)sz;
}
