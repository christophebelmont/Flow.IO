#pragma once
#include <optional>
#include <unordered_map>
#include <mutex>
#include "driver/ledc.h"
#include "driver/gpio.h"

namespace app::io {

struct PwmChannel { int channel; int timer; gpio_num_t pin; double freq_hz; };

/** LEDC PWM allocator for frequency/duty control. */
class PwmManager {
public:
  std::optional<PwmChannel> allocate(gpio_num_t pin, double freq_hz);
  bool setDuty(const PwmChannel& ch, double duty_0_1);
  void free(const PwmChannel& ch);

private:
  std::mutex m_;
  int next_channel_{0};
  int timer_id_{0}; // reuse a single timer for simplicity
  std::unordered_map<gpio_num_t, PwmChannel> by_pin_;
};

} // namespace app::io
