#pragma once
#include <cstddef>
#include <cstdint>

namespace app::diag {

struct HealthMetrics { size_t free_heap; size_t min_free_heap; uint32_t event_queue_drops; };

/** Snapshot basic system health periodically. */
class Health {
public:
  void sample();
  HealthMetrics last() const { return last_; }
private:
  HealthMetrics last_{};
};

} // namespace app::diag
