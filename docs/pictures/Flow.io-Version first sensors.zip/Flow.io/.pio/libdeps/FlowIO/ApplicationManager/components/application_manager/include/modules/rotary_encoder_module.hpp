#pragma once
#include "modules/module.hpp"

namespace app::modules {

/** Stub: PCNT-based quadrature encoder (TODO). */
class RotaryEncoderModule : public Module {
public:
  RotaryEncoderModule(ModuleId id) : id_(id) {}
  bool init() override { return true; }
  bool start() override { return true; }
  void stop() override {}
  ModuleDescriptor descriptor() const override { return {id_, "encoder", "rotary"}; }
private:
  ModuleId id_;
};

} // namespace app::modules
