#pragma once
#include <unordered_map>
#include <string>
#include <mutex>
#include "driver/gpio.h"

namespace app::io {

enum class PinMode { Input, InputPullUp, Output, OutputOpenDrain };

struct PinClaim { gpio_num_t pin; PinMode mode; const char* owner; };

/** Conflict-safe pin ownership and basic I/O helpers. */
class PinManager {
public:
  bool claim(const PinClaim& c);   // false if already owned
  void release(gpio_num_t pin);

  bool write(gpio_num_t pin, bool level);
  bool read(gpio_num_t pin, bool& level) const;

  /** If claim fails, last known owner (empty if none). */
  std::string ownerOf(gpio_num_t pin) const;

private:
  bool configure(const PinClaim& c);

  mutable std::mutex m_;
  std::unordered_map<gpio_num_t, PinClaim> claims_;
};

} // namespace app::io
