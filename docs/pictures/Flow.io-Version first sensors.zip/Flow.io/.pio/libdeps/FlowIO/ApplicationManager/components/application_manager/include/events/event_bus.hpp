#pragma once
#include <cstdint>
#include <functional>
#include <unordered_map>
#include <vector>
#include <mutex>
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"

namespace app::events {

/** Basic event types. Extend as needed. */
enum class EventType : uint16_t {
  Boot, Tick, ButtonPressed, ButtonReleased, EncoderDelta,
  ParamSample, RuleTriggered, User, Error
};

/** Event payload with generic integer/float slots and timestamps. */
struct Event {
  EventType type;
  uint32_t  module_id{0};
  int64_t   ts_us_app{0};
  int64_t   ts_rt{0};      // 0 if unknown
  int32_t   i1{0};
  double    f1{0.0};
};

using EventHandler = std::function<void(const Event&)>;

/**
 * @brief Non-blocking EventBus with FreeRTOS queue + dispatcher task.
 *
 * Publish is non-blocking (drop policy configurable later). Subscribers
 * are per-event-type. A single dispatcher task pulls from the queue and
 * fan-outs to handlers.
 */
class EventBus {
public:
  /** Create queue and start dispatcher task. */
  bool begin(size_t queue_depth = 64);

  /** Publish event (non-blocking). TODO: configurable back-pressure policy. */
  bool publish(const Event& e, TickType_t timeout = 0);

  /** Subscribe to a specific EventType; returns subscription id. */
  int subscribe(EventType t, EventHandler cb);

  /** Remove subscription by id. */
  void unsubscribe(int id);

  /** Stats: number of drops due to back-pressure. */
  uint32_t drops() const { return drops_; }

private:
  static void dispatchTaskThunk(void* arg);
  void dispatchTask();
  void fanout(const Event& e);

  QueueHandle_t q_{nullptr};
  TaskHandle_t  task_{nullptr};

  mutable std::mutex m_;
  int next_sub_id_{1};
  std::unordered_map<int, std::pair<EventType, EventHandler>> subs_by_id_;
  std::unordered_map<EventType, std::vector<int>> subs_by_type_;
  volatile uint32_t drops_{0};
};

} // namespace app::events
