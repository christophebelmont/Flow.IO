#include "io/bus_manager.hpp"

using namespace app::io;

static bool inc(std::unordered_map<int,int>& m, int k) { return ++m[k], true; }
static void dec(std::unordered_map<int,int>& m, int k) { if (--m[k] <= 0) m.erase(k); }

bool BusManager::refI2C(i2c_port_t port) { std::lock_guard<std::mutex> l(m_); return inc(i2c_refs_, (int)port); }
void BusManager::unrefI2C(i2c_port_t port) { std::lock_guard<std::mutex> l(m_); dec(i2c_refs_, (int)port); }
bool BusManager::refSPI(spi_host_device_t h){ std::lock_guard<std::mutex> l(m_); return inc(spi_refs_, (int)h); }
void BusManager::unrefSPI(spi_host_device_t h){ std::lock_guard<std::mutex> l(m_); dec(spi_refs_, (int)h); }
bool BusManager::refUART(uart_port_t p){ std::lock_guard<std::mutex> l(m_); return inc(uart_refs_, (int)p); }
void BusManager::unrefUART(uart_port_t p){ std::lock_guard<std::mutex> l(m_); dec(uart_refs_, (int)p); }
