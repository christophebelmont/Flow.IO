#include "modules/heater_module.hpp"
#include "app/application_manager.hpp"
#include <algorithm>

using namespace app::modules;

HeaterModule::HeaterModule(ModuleId id, const HeaterConfig& cfg) : id_(id), cfg_(cfg) {}

bool HeaterModule::init() {
  pwm_ = app::ApplicationManager::instance().services().get<app::io::PwmManager>().get();
  return pwm_ != nullptr;
}

bool HeaterModule::start() {
  ch_ = pwm_->allocate(cfg_.pin, cfg_.pwm_freq);
  return ch_.has_value();
}

void HeaterModule::stop() {
  if (ch_) { pwm_->free(*ch_); ch_.reset(); }
}

void HeaterModule::setDuty(double duty_0_1) {
  if (!ch_) return;
  double d = std::clamp(duty_0_1, cfg_.duty_min, cfg_.duty_max);
  pwm_->setDuty(*ch_, d);
}

ModuleDescriptor HeaterModule::descriptor() const { return {id_, "heater", "heater"}; }
