#include "sched/scheduler.hpp"
#include <cstring>
#include <cstdio>
#include <utility>

using namespace app::sched;

void Scheduler::thunk(void* arg) {
  auto* a = static_cast<Action*>(arg);
  (*a)();
}

bool Scheduler::scheduleEvery(std::chrono::milliseconds period, Action a) {
  if (period.count() < 1) return false;
  esp_timer_handle_t h{};
  auto* stored = new Action(std::move(a));
  esp_timer_create_args_t args{
    .callback = [](void* p){ thunk(p); },
    .arg = stored,
    .dispatch_method = ESP_TIMER_TASK,
    .name = "sched_every"
  };
  if (esp_timer_create(&args, &h) != ESP_OK) { delete stored; return false; }
  if (esp_timer_start_periodic(h, period.count() * 1000) != ESP_OK) { esp_timer_delete(h); delete stored; return false; }
  timers_.push_back({h, *stored});
  return true;
}

bool Scheduler::scheduleCron(const CronSpec& spec, Action a) {
  // Minimal support for "@every <Ns|ms>"
  if (!spec.spec || std::strncmp(spec.spec, "@every ", 7) != 0) return false;
  int val = 0; char unit[4] = {0};
  if (sscanf(spec.spec + 7, "%d%3s", &val, unit) != 2) return false;
  long ms = 0;
  if (std::strcmp(unit, "ms") == 0) ms = val;
  else if (std::strcmp(unit, "s") == 0) ms = val * 1000;
  else return false;
  return scheduleEvery(std::chrono::milliseconds(ms), std::move(a));
}

Scheduler::~Scheduler() {
  for (auto& it : timers_) { esp_timer_stop(it.h); esp_timer_delete(it.h); }
}
